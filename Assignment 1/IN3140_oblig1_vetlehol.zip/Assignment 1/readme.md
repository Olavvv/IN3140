### What was difficult?

- I found the last task difficult, (inverse kinematics), i didnt find the 'idea' difficult, but the 'math' of it was. The math in general was quite hard as i havent done math in a while.
- I believe i could have done the last task better.