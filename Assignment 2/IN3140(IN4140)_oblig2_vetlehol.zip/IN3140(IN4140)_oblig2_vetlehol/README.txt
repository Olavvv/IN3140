What i found difficult: I struggle alot with the geometric algebra in these tasks, i keep getting lost alot.
What i found easy: The programming part, i find easy, the implementation part, and how to use them (funny if i got them wrong now).

I definitely could have done the "math" part better.